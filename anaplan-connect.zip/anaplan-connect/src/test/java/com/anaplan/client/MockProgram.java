package com.anaplan.client;

/**
 * Created by Spondon Saha
 * User: spondonsaha
 * Date: 8/8/17
 * Time: 7:56 AM
 */
public class MockProgram extends Program {
}
