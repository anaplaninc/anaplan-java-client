// Copyright 2012 Anaplan Limited
package com.anaplan.client;

public final class CertConstants {
    public static final String CERT_PREFIX = "-----BEGIN CERTIFICATE-----";
    public static final String CERT_SUFFIX = "-----END CERTIFICATE-----";
}