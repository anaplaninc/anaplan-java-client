package com.anaplan.client.dto;

/**
 * Created by Spondon Saha
 * User: spondonsaha
 * Date: 6/21/17
 * Time: 7:05 PM
 */
public class ChunkData extends NamedObjectData {
}
