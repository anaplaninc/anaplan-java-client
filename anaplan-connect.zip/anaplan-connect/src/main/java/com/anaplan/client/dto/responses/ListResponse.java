package com.anaplan.client.dto.responses;

import java.util.List;

/**
 * Created by Spondon Saha
 * User: spondonsaha
 * Date: 7/5/17
 * Time: 1:42 PM
 */
public abstract class ListResponse<T> extends ObjectResponse<List<T>> {
}
