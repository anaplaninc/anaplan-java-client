package com.anaplan.client.dto;

/**
 * Created by Spondon Saha
 * User: spondonsaha
 * Date: 6/21/17
 * Time: 3:40 PM
 */
public class ViewData extends NamedObjectData {
}
