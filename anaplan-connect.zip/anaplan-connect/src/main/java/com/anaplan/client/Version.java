// This file is mechanically generated; Changes should be made in build.xml
package com.anaplan.client;

public interface Version {
    static int API_MAJOR = 2, API_MINOR = 0;
    static int REVISION = 0;
    static String RELEASE = "-release";
}