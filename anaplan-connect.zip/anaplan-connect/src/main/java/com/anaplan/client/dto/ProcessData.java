package com.anaplan.client.dto;

/**
 * Created by Spondon Saha
 * User: spondonsaha
 * Date: 6/21/17
 * Time: 3:31 PM
 */
public class ProcessData extends NamedObjectData {
}
