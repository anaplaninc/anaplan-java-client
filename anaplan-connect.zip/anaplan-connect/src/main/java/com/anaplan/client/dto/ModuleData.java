package com.anaplan.client.dto;

/**
 * Created by Spondon Saha
 * User: spondonsaha
 * Date: 6/21/17
 * Time: 3:30 PM
 */
public class ModuleData extends NamedObjectData {
}
